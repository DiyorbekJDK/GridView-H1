package com.example.homework_031122

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.GridView
import android.widget.ImageView
import android.widget.ListView
import com.example.homework_031122.adapter.DoctorsAdapter
import com.example.homework_031122.adapter.ToolAdapter
import com.example.homework_031122.model.DoctorsInfo
import com.example.homework_031122.model.ToolInfo

class ThirdActivity : AppCompatActivity() {
    private lateinit var listView: ListView
    private val docAdapter by lazy { DoctorsAdapter(this, docList()) }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_third)
        supportActionBar?.hide()
        listView = findViewById(R.id.listView)
        listView.adapter = docAdapter
        val btn: ImageView = findViewById(R.id.backToSecond)
        btn.setOnClickListener {
            startActivity(Intent(this, SecondActivity::class.java))
            finish()
        }
    }

    private fun docList(): MutableList<DoctorsInfo> {
        val list = mutableListOf<DoctorsInfo>()
        list.add(DoctorsInfo(R.drawable.first_doctor, "Kotlinjon", "Made by java", 4.5f))
        list.add(DoctorsInfo(R.drawable.first_doctor, "Javabek", "Very good language", 5.0f))
        list.add(DoctorsInfo(R.drawable.first_doctor, "Abu ali ibn Sino", "Was well Doctor", 3.5f))
        list.add(DoctorsInfo(R.drawable.first_doctor, "Android", "Made by Google", 2.5f))
        list.add(DoctorsInfo(R.drawable.first_doctor, "C++", "Microsoft Corporation", 1.0f))
        list.add(DoctorsInfo(R.drawable.first_doctor, "Python", "Simple Language", 3.0f))
        return list
    }
}