package com.example.homework_031122

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.GridView
import android.widget.ImageView
import com.example.homework_031122.adapter.ToolAdapter
import com.example.homework_031122.model.ToolInfo

class SecondActivity : AppCompatActivity() {
    private lateinit var gridView: GridView
    private val toolAdapter by lazy { ToolAdapter(this,toolsList()) }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_second)
        supportActionBar?.hide()
        gridView = findViewById(R.id.gridView)
        gridView.adapter = toolAdapter
        val btn: ImageView = findViewById(R.id.backToFirst)
        btn.setOnClickListener {
            val intent = Intent(this,MainActivity::class.java)
            startActivity(intent)
            finish()
        }
        val btn2:ImageView = findViewById(R.id.toLast)
        btn2.setOnClickListener {
            val ietntn2 = Intent(this,ThirdActivity::class.java)
            startActivity(ietntn2)
            finish()
        }
    }
    private fun toolsList(): MutableList<ToolInfo>{
        val list = mutableListOf <ToolInfo>()
        list.add(ToolInfo(R.drawable.body,"Body"))
        list.add(ToolInfo(R.drawable.heart,"Treat your Heart"))
        list.add(ToolInfo(R.drawable.head,"Treat your Head"))
        list.add(ToolInfo(R.drawable.termometr,"Count your temperature"))
        list.add(ToolInfo(R.drawable.eye,"Make better eye"))
        list.add(ToolInfo(R.drawable.lungs,"Breath Clearly"))
        list.add(ToolInfo(R.drawable.brain,"Problems with Brain?"))
        list.add(ToolInfo(R.drawable.stomack,"Eat Healthy"))
        return list
    }
}