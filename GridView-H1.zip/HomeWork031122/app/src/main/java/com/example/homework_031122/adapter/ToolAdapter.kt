package com.example.homework_031122.adapter

import android.annotation.SuppressLint
import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.widget.SwitchCompat
import com.example.homework_031122.R
import com.example.homework_031122.model.ToolInfo

class ToolAdapter(context: Context, private val toolList: MutableList<ToolInfo>):BaseAdapter() {
    private val layoutInflater: LayoutInflater = context.getSystemService(Context.LAYOUT_INFLATER_SERVICE) as LayoutInflater
    override fun getCount(): Int = toolList.size

    override fun getItem(p0: Int): ToolInfo = toolList[p0]

    override fun getItemId(p0: Int): Long = p0.toLong()

    @SuppressLint("ViewHolder")
    override fun getView(p0: Int, p1: View?, p2: ViewGroup?): View {
        val view: View = layoutInflater.inflate(R.layout.grid_item,p2,false)
        val toolImage: ImageView = view.findViewById(R.id.toolImage)
        val toolName: TextView = view.findViewById(R.id.toolName)
        val tool = getItem(p0) as ToolInfo
        toolImage.setImageResource(tool.image)
        toolName.text = tool.text
        return view
    }
}