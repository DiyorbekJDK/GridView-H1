package com.example.homework_031122.model

data class DoctorsInfo(
    val image: Int,
    val name: String,
    val desc: String,
    val ratedStars: Float
)
