package com.example.homework_031122

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.GridView
import android.widget.ImageView
import com.example.homework_031122.adapter.ToolAdapter
import com.example.homework_031122.model.ToolInfo

class MainActivity : AppCompatActivity() {
    private lateinit var gridView: GridView
    private val toolAdapter by lazy { ToolAdapter(this, toolsList()) }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        supportActionBar?.hide()
        gridView = findViewById(R.id.GridView)
        gridView.adapter = toolAdapter
        val imageView: ImageView = findViewById(R.id.imageView)
        imageView.setOnClickListener {
            val itent = Intent(this, SecondActivity::class.java)
            startActivity(itent)
        }

    }

    private fun toolsList(): MutableList<ToolInfo> {
        val list = mutableListOf<ToolInfo>()
        list.add(ToolInfo(R.drawable.stethoscope, "Longs and Heart"))
        list.add(ToolInfo(R.drawable.honey, "Honey and Plants"))
        list.add(ToolInfo(R.drawable.siren, "Siren and air"))
        list.add(ToolInfo(R.drawable.a_drop, "A drop and water"))
        list.add(ToolInfo(R.drawable.question, "Help"))
        return list
    }
}