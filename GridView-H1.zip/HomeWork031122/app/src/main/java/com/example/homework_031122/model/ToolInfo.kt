package com.example.homework_031122.model

data class ToolInfo(
    val image: Int,
    val text: String
)
